#include <Windows.h>
#include <iostream>
#include <Minhook.h>
uintptr_t GameAssembly = (uintptr_t)GetModuleHandle("GameAssembly.dll");
uintptr_t Spectateoutlineoffset = 0x88A100;
uintptr_t get_isDeadoffset = 0x8D5B30;
uintptr_t IsInsideSomethingoffset = 0x8A0810;
uintptr_t Pickup_Magazine_PC_setAmmotypeoffset = 0x4A8570;
;
//uintptr_t recoiloffset = 0x730CE0;
//uintptr_t setRoundsoffset = 0x5B13A0;
//cookie 5/15/2024

bool(__fastcall* Isinsidesomething_O) (DWORD*, DWORD*);
bool __stdcall  Isinsidesomething_RD(DWORD* __this, DWORD* method)
{
    return 0;
}

bool(__fastcall* SpectateOutline_O)(DWORD*, DWORD*);
bool __stdcall SpectateOutline_RD(DWORD* __this, DWORD* method)
{
    return 1;
}

bool(__fastcall* get_isDead_o)(DWORD*, DWORD*);
bool __stdcall get_isDead_RD(DWORD* __this, DWORD* method)
{
    return 1;
}

/*
* 0x06 = highexplosive
    {
      "Address": 4883824,
      "Name": "Pickup_Magazine$$RPC_SetAmmoType",
      "Signature": "void Pickup_Magazine__RPC_SetAmmoType (Pickup_Magazine_o* __this, uint8_t ammoTypeByte, DPI_Networking_DPINetworkMessageInfo_o info, const MethodInfo* method);",
      "TypeSignature": "viiii"
    },
*/

bool(__fastcall* Pickup_Magazine_PC_SetAmmoType_O)(DWORD*,uint8_t, DWORD* ,DWORD*);
bool __stdcall Pickup_Magazine_PC_SetAmmoType_RD(DWORD* __this, uint8_t ammoTypeByte,DWORD* info,DWORD* method)
{
    ammoTypeByte = 0x06;
    return 0;
}
