#include "hacking.h"
int minhookhacking()
{
    
    MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + IsInsideSomethingoffset), &Isinsidesomething_RD, reinterpret_cast<LPVOID*>(Isinsidesomething_O));
    MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + Spectateoutlineoffset), &SpectateOutline_RD, reinterpret_cast<LPVOID*>(SpectateOutline_O));
    MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + get_isDeadoffset), &get_isDead_RD, reinterpret_cast<LPVOID*>(&get_isDead_o));
    //MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + recoiloffset), &recoil_RD, reinterpret_cast<LPVOID*>(&recoil_O));
    //MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + setRoundsoffset), &setRoundsLaoded_RD, reinterpret_cast<LPVOID*>(&setRoundsLaoded_O));
    MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + IsInsideSomethingoffset), &Isinsidesomething_RD, reinterpret_cast<LPVOID*>(&Isinsidesomething_O));
    MH_CreateHook(reinterpret_cast<LPVOID*>(GameAssembly + Pickup_Magazine_PC_setAmmotypeoffset), &Pickup_Magazine_PC_SetAmmoType_RD, reinterpret_cast<LPVOID*>(&Pickup_Magazine_PC_SetAmmoType_O));
    MH_EnableHook(MH_ALL_HOOKS);
    Sleep(99999999999);
    return 0;
}

bool console() {
    AllocConsole(); 
    FILE* f;
    freopen_s(&f, "CONOUT$", "w", stdout);
    if (f == nullptr) {
        std::cerr << "Failed!" << std::endl;
    }
    std::cout << "Getting stuff ready" << std::endl;
    
    return true;
}
DWORD WINAPI MainThread(HMODULE hModule)
{
    console();
    if (console() == true)
    {
        MH_Initialize();
        minhookhacking();
    }
    return 0;
}


BOOL WINAPI DllMain(
    HINSTANCE hModule,  // handle to DLL module
    DWORD fdwReason,     // reason for calling function
    LPVOID lpvReserved)  // reserved
{
    // Perform actions based on the reason for calling.
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        // Initialize once for each new process.
        // Return FALSE to fail DLL load.
    case DLL_THREAD_ATTACH:
        CloseHandle(CreateThread(nullptr, 0, (LPTHREAD_START_ROUTINE)MainThread, hModule, 0, nullptr));
    case DLL_THREAD_DETACH:
        // Do thread-specific cleanup
    case DLL_PROCESS_DETACH:
        // Perform any necessary cleanup.
        break;
    }
    return true;
}